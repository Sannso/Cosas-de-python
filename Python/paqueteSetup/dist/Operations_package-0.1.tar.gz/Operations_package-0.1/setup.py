from setuptools import setup

setup(
    name = "Operations_package",
    version = "0.1",
    description = "Paquete de operaciones",
    author = "Santiago Sosa Herrera",
    author_email = "santiago.sosa1@utp.edu.co",
    packages = ["package_calculos", "package_calculos.calculos_basicos"]
)
